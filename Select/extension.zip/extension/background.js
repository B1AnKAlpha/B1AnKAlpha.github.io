const RULE_ID = 1;

async function installRules() {
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [RULE_ID],
      addRules: [
        {
          id: RULE_ID,
          priority: 10,
          action: {
            type: "modifyHeaders",
            requestHeaders: [
              { header: "Origin", operation: "set", value: "https://app.huoshui.org" },
              { header: "Referer", operation: "set", value: "https://app.huoshui.org/" }
            ]
          },
          condition: {
            urlFilter: "*://lean.huoshui.org/*",
            resourceTypes: ["xmlhttprequest", "sub_frame", "other"]
          }
        }
      ]
    });
    console.info("[教师评分扩展] DNR header rewrite rule installed");
  } catch (err) {
    console.warn("[教师评分扩展] Failed to install DNR rule", err);
  }
}

chrome.runtime.onInstalled.addListener(() => installRules());
chrome.runtime.onStartup?.addListener(() => installRules());
// 兜底：立即尝试一次，防止未触发上述事件
installRules();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "hsApi") return;
  (async () => {
    try {
      const { path, params } = message;
      const url = new URL(`https://lean.huoshui.org/1.1${path}`);
      Object.entries(params || {}).forEach(([k, v]) =>
        url.searchParams.set(k, typeof v === "string" ? v : JSON.stringify(v))
      );
      const res = await fetch(url.toString(), {
        headers: {
          "X-LC-Id": "zwjjm3MbxDYRKny9f31amkXq",
          "X-LC-Key": "PczcQb9HEBCLtLj4ohJ7ePj5"
        },
        credentials: "omit"
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || json?.error) {
        sendResponse({ error: json?.error || `HTTP ${res.status}`, code: json?.code });
      } else {
        sendResponse(json);
      }
    } catch (err) {
      sendResponse({ error: err?.message || String(err) });
    }
  })();
  return true; // keep the message channel open
});
