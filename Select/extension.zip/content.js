(() => {
  // ---------- 配置区：如需适配新的 DOM，请调整选择器 ----------
  const TEACHER_SELECTORS = [
    "td.teacher",
    ".teacher",
    ".teacher-name",
    ".teacherName",
    "a.teacher",
    "a.teacher-name"
  ];
  const COURSE_SELECTORS = [
    "td.course",
    ".course",
    ".course-name",
    ".courseName"
  ];
  const HS_APP_ID = "zwjjm3MbxDYRKny9f31amkXq";
  const HS_APP_KEY = "PczcQb9HEBCLtLj4ohJ7ePj5";
  const HS_API_BASE = "https://lean.huoshui.org/1.1";

  // ---------- 全局状态 ----------
  const cache = new Map(); // key: url, value: { score, comments }
  let hideTimer = null;
  let currentKey = "";
  let isLight = window.matchMedia("(prefers-color-scheme: light)").matches;

  // ---------- DOM: 悬浮窗 ----------
  const popup = document.createElement("div");
  popup.className = "hs-prof-popup";
  document.body.appendChild(popup);

  function setPopupTheme() {
    if (isLight) {
      popup.classList.add("light");
    } else {
      popup.classList.remove("light");
    }
  }
  setPopupTheme();
  window.matchMedia("(prefers-color-scheme: light)").addEventListener("change", (e) => {
    isLight = e.matches;
    setPopupTheme();
  });

  function escapeHtml(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function pickFirstNumber(str) {
    if (!str) return "";
    const m = str.match(/([0-9]+(?:\.[0-9]+)?)/);
    return m ? m[1] : "";
  }

  function positionPopup(x, y) {
    // 先显示到可计算尺寸，再回置
    popup.style.left = "0px";
    popup.style.top = "0px";
    popup.style.display = "block";
    const rect = popup.getBoundingClientRect();
    const pad = 12;
    let left = x + 14;
    let top = y + 14;
    if (left + rect.width + pad > window.innerWidth) {
      left = x - rect.width - 14;
    }
    if (top + rect.height + pad > window.innerHeight) {
      top = y - rect.height - 14;
    }
    popup.style.left = `${Math.max(pad, left)}px`;
    popup.style.top = `${Math.max(pad, top)}px`;
  }

  function showPopup() {
    popup.classList.add("visible");
  }

  function hidePopup() {
    popup.classList.remove("visible");
    popup.style.display = "none";
  }

  popup.addEventListener("mouseenter", () => clearTimeout(hideTimer));
  popup.addEventListener("mouseleave", () => (hideTimer = setTimeout(hidePopup, 700)));

  // ---------- 数据抓取 ----------
  function readText(el) {
    return (el?.textContent || "").trim();
  }

  function findInRow(row, selectors) {
    for (const sel of selectors) {
      const el = row.querySelector(sel);
      const t = readText(el);
      if (t) return t;
    }
    return "";
  }

  function collectContext(teacherName, sourceEl) {
    const row = sourceEl.closest("tr");
    const courseName =
      sourceEl.dataset.course ||
      (row ? findInRow(row, COURSE_SELECTORS) : "") ||
      "";
    const courseId = sourceEl.dataset.courseId || "";
    const dept = sourceEl.dataset.dept || "";
    return { teacherName, courseName, courseId, dept };
  }

  function buildProfUrl(teacherName, sourceEl) {
    const { courseName, courseId, dept } = collectContext(teacherName, sourceEl);
    const extra = new URLSearchParams();
    if (courseName) extra.set("course", courseName);
    if (courseId) extra.set("courseId", courseId);
    if (dept) extra.set("dept", dept);
    extra.set("prof", teacherName);
    const qs = extra.toString();
    return `https://app.huoshui.org/profs/${encodeURIComponent(teacherName)}${qs ? "?" + qs : ""}`;
  }

  function parseScore(doc, rawHtml) {
    const scoreSelectors = [
      "[data-testid='prof-score']",
      ".ant-rate-text",
      ".rating-score",
      ".score-value",
      ".score",
      ".overall-score",
      ".OverallScore",
      ".chart-tab .tab.active"
    ];
    for (const sel of scoreSelectors) {
      const text = readText(doc.querySelector(sel));
      if (!text) continue;
      const num = pickFirstNumber(text);
      return num || text;
    }
    // 兜底：常见格式 4.5 / 5 或 "评分 4.3"
    const regexes = [
      /([0-9]+(?:\.[0-9]+)?)\s*分/,
      /([0-9]+(?:\.[0-9]+)?)\s*\/\s*5/,
      /评分[:：]?\s*([0-9]+(?:\.[0-9]+)?)/,
      /score"\s*:\s*([0-9]+(?:\.[0-9]+)?)/i,
      /overallScore"\s*:\s*([0-9]+(?:\.[0-9]+)?)/i
    ];
    for (const r of regexes) {
      const m = rawHtml.match(r);
      if (m) return m[1];
    }
    return "暂无";
  }

  function parseComments(doc, rawHtml) {
    const commentSelectors = [
      ".review-comment .ion-text-wrap",
      ".review-item-container .ion-text-wrap",
      ".review-item-container .review-comment",
      ".review-comment",
      ".comment-item",
      ".comment-content",
      ".ant-comment-content",
      ".ant-comment-content-detail",
      ".comment",
      ".review",
      ".comment-body"
    ];
    const comments = [];
    for (const sel of commentSelectors) {
      doc.querySelectorAll(sel).forEach((el) => {
        const t = readText(el);
        if (t) comments.push(t);
      });
      if (comments.length) break;
    }

    // 兜底：从脚本 JSON 里粗暴抽取
    if (!comments.length) {
      const jsonMatches = rawHtml.match(/"comment[^"]*"\s*:\s*"([^"]{5,200})"/gi) || [];
      jsonMatches.forEach((m) => {
        const txt = m.split(":")[1].replace(/(^\s*")|("\s*$)/g, "");
        if (txt) comments.push(txt);
      });
    }

    return comments.slice(0, 6);
  }

  async function fetchHuoshuiApi(path, params) {
    const payload = {
      where: params?.where,
      keys: params?.keys,
      order: params?.order,
      limit: params?.limit
    };
    const tryDirect = async (base) => {
      const url = new URL(`${base}${path}`);
      Object.entries(payload)
        .filter(([, v]) => v !== undefined && v !== null)
        .forEach(([k, v]) => url.searchParams.set(k, typeof v === "string" ? v : JSON.stringify(v)));
      const res = await fetch(url.toString(), {
        headers: {
          "X-LC-Id": HS_APP_ID,
          "X-LC-Key": HS_APP_KEY
        },
        credentials: "omit"
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || json?.error) {
        const err = new Error(json?.error || `HTTP ${res.status}`);
        err.code = json?.code;
        throw err;
      }
      return json;
    };

    // 1) 尝试走后台代理（成功则避免页面 CSP/Origin）
    const tryBg = () =>
      new Promise((resolve, reject) => {
        if (!chrome?.runtime?.sendMessage) {
          reject(new Error("runtime unavailable"));
          return;
        }
        chrome.runtime.sendMessage({ type: "hsApi", path, params: payload }, (resp) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (!resp || resp.error) {
            reject(new Error(resp?.error || "未知错误"));
            return;
          }
          resolve(resp);
        });
      });

    try {
      return await tryBg();
    } catch (_) {
      /* ignore and fallback */
    }

    // 2) 直接打 lean 域
    try {
      return await tryDirect("https://lean.huoshui.org/1.1");
    } catch (_) {
      /* ignore and fallback */
    }

    // 3) 再试 app 域（有时允许 CORS）
    return tryDirect("https://app.huoshui.org/1.1");
  }

  async function fetchFromApi(teacherName, ctx) {
    const courseWhere = { prof: teacherName };
    if (ctx.dept) courseWhere.dept = ctx.dept;
    const coursesResp = await fetchHuoshuiApi("/classes/Courses", {
      where: courseWhere,
      keys: "prof,dept,name,rateOverall,reviewCount",
      limit: 100
    });
    const courses = coursesResp.results || [];
    const reviewCount = courses.reduce((sum, c) => sum + (c.reviewCount || 0), 0);
    const weightedScore =
      reviewCount === 0
        ? 0
      : courses.reduce(
          (sum, c) => sum + (c.rateOverall || 0) * (c.reviewCount || 0),
          0
        ) / reviewCount;

    const reviewWhere = { profName: teacherName };
    // 如果携带课程名则稍微收紧范围，避免同名教师串场
    if (ctx.courseName) reviewWhere.courseName = ctx.courseName;
    const reviewsResp = await fetchHuoshuiApi("/classes/Reviews", {
      where: reviewWhere,
      order: "-createdAt",
      keys: "comment,courseName,profName,rating",
      limit: 6
    });
    const reviews = reviewsResp.results || [];
    const comments = reviews.map((r) => (r.comment || "").trim()).filter(Boolean) || [];
    const ratingFromReviews = reviews
      .map((r) => {
        const rt = r.rating || {};
        if (typeof rt.overall === "number") return rt.overall;
        if (typeof rt.rate1 === "number" && typeof rt.rate2 === "number" && typeof rt.rate3 === "number") {
          return (rt.rate1 + rt.rate2 + rt.rate3) / 3;
        }
        return null;
      })
      .filter((v) => typeof v === "number");

    return {
      score:
        reviewCount
          ? weightedScore.toFixed(1)
          : ratingFromReviews.length
            ? (ratingFromReviews.reduce((a, b) => a + b, 0) / ratingFromReviews.length).toFixed(1)
            : "暂无",
      comments
    };
  }

  async function fetchFromHtml(url) {
    const res = await fetch(url, { credentials: "omit" });
    if (!res.ok) throw new Error(`请求失败: HTTP ${res.status}`);
    const html = await res.text();
    const doc = new DOMParser().parseFromString(html, "text/html");
    const score = parseScore(doc, html);
    const comments = parseComments(doc, html);
    if (score === "暂无" || comments.length === 0) {
      console.warn("[教师评分扩展] 解析为空，URL:", url, "首段:", html.slice(0, 300));
    }
    return { score, comments };
  }

  async function fetchProfData(teacherName, sourceEl) {
    const ctx = collectContext(teacherName, sourceEl);
    const url = buildProfUrl(teacherName, sourceEl);
    if (cache.has(url)) return { url, ...cache.get(url) };

    let data = null;
    try {
      data = await fetchFromApi(teacherName, ctx);
    } catch (err) {
      console.warn("[教师评分扩展] API 获取失败，将回退到页面解析", err?.message || err);
    }

    if (!data || (data.score === "暂无" && (!data.comments || data.comments.length === 0))) {
      data = await fetchFromHtml(url);
    }

    cache.set(url, data);
    return { url, ...data };
  }

  function renderPopup(teacher, data, sourceUrl) {
    const commentsHtml =
      data.comments && data.comments.length
        ? data.comments
            .map((c) => `<div class="hs-prof-comment">${escapeHtml(c)}</div>`)
            .join("")
        : `<div class="hs-prof-comment">暂无评价</div>`;

    popup.innerHTML = `
      <div class="hs-prof-header">
        <span title="${escapeHtml(teacher)}">${escapeHtml(teacher)}</span>
        <span class="hs-prof-score">评分：${escapeHtml(data.score || "暂无")}</span>
      </div>
      <div class="hs-prof-comments">${commentsHtml}</div>
      <div style="margin-top:6px;font-size:12px;color:${isLight ? "#666" : "#999"}">
        数据源：<a href="${sourceUrl}" target="_blank" rel="noreferrer" style="color:${isLight ? "#ea4c89" : "#f58fb0"}">huoshui</a>
      </div>
    `;
  }

  function renderLoading(teacher) {
    popup.innerHTML = `
      <div class="hs-prof-header">
        <span>${escapeHtml(teacher)}</span>
        <span class="hs-prof-loading">加载中...</span>
      </div>
    `;
  }

  function renderError(teacher, msg) {
    popup.innerHTML = `
      <div class="hs-prof-header">
        <span>${escapeHtml(teacher)}</span>
        <span style="color:#f66">加载失败</span>
      </div>
      <div style="margin-top:6px;font-size:12px;">${escapeHtml(msg)}</div>
    `;
  }

  // ---------- 事件绑定 ----------
  function attachHover(el, teacherName) {
    el.dataset.hsProfBound = "1";
    let showTimer = null;

    el.addEventListener("mouseenter", async (e) => {
      clearTimeout(hideTimer);
      if (showTimer) clearTimeout(showTimer);
      showTimer = setTimeout(async () => {
        currentKey = teacherName + "_" + Date.now();
        renderLoading(teacherName);
        positionPopup(e.clientX, e.clientY);
        popup.style.display = "block";
        showPopup();
        try {
          const data = await fetchProfData(teacherName, el);
          if (!popup.classList.contains("visible")) return;
          renderPopup(teacherName, data, data.url);
          positionPopup(e.clientX, e.clientY);
        } catch (err) {
          renderError(teacherName, err.message || "未知错误");
        }
      }, 250);
    });

    el.addEventListener("mousemove", (e) => {
      clearTimeout(hideTimer);
      positionPopup(e.clientX, e.clientY);
    });

    el.addEventListener("mouseleave", () => {
      if (showTimer) {
        clearTimeout(showTimer);
        showTimer = null;
      }
      hideTimer = setTimeout(hidePopup, 700);
    });
  }

  function bindAllTeachers(rootDoc) {
    TEACHER_SELECTORS.forEach((sel) => {
      rootDoc.querySelectorAll(sel).forEach((el) => {
        if (el.dataset.hsProfBound) return;
        const name = readText(el);
        if (name) attachHover(el, name);
      });
    });

    // 兜底：通过表头文本“教师”定位列，再绑定同列单元格
    rootDoc.querySelectorAll("table").forEach((table) => {
      let teacherCol = -1;
      const headerRow =
        table.querySelector("thead tr") ||
        table.querySelector("tr");
      if (!headerRow) return;
      const headers = [...headerRow.children];
      headers.forEach((cell, idx) => {
        const t = readText(cell);
        if (teacherCol === -1 && /教师|老师/.test(t)) teacherCol = idx;
      });
      if (teacherCol === -1) return;
      const rows = table.querySelectorAll("tbody tr, tr");
      rows.forEach((row) => {
        const cells = row.children;
        if (!cells || cells.length <= teacherCol) return;
        const cell = cells[teacherCol];
        const name = readText(cell);
        if (!name || cell.dataset.hsProfBound) return;
        attachHover(cell, name);
      });
    });
  }

  function sameOriginFrames(rootDoc) {
    const docs = [rootDoc];
    rootDoc.querySelectorAll("iframe").forEach((iframe) => {
      try {
        if (iframe.contentDocument) docs.push(iframe.contentDocument);
      } catch (_) {
        /* ignore cross-origin */
      }
    });
    return docs;
  }

  function bindAllDocs(rootDoc) {
    const docs = sameOriginFrames(rootDoc);
    docs.forEach((d) => bindAllTeachers(d));
  }

  bindAllDocs(document);
  const initialBound = document.querySelectorAll("[data-hs-prof-bound='1']").length;
  console.info("[教师评分扩展] 已绑定教师元素数量(含 iframe):", initialBound);

  const mo = new MutationObserver((mutations) => {
    for (const m of mutations) {
      m.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          // 新增 iframe 时也尝试绑定内部
          if (node.tagName === "IFRAME") {
            try {
              node.addEventListener("load", () => {
                if (node.contentDocument) bindAllDocs(node.contentDocument);
              });
              if (node.contentDocument) bindAllDocs(node.contentDocument);
            } catch (_) {
              /* cross-origin ignore */
            }
          }
          bindAllDocs(node);
        }
      });
    }
  });
  mo.observe(document.body, { childList: true, subtree: true });

  // 若需要手动重试绑定，可在控制台执行 window.hsProfRebind()
  window.hsProfRebind = () => {
    document.querySelectorAll("[data-hs-prof-bound]").forEach((el) => delete el.dataset.hsProfBound);
    bindAllDocs(document);
    const cnt = document.querySelectorAll("[data-hs-prof-bound='1']").length;
    console.info("[教师评分扩展] 重新绑定教师元素数量:", cnt);
    return cnt;
  };
})();
